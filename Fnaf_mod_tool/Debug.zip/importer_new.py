import bpy
import json
import os
import time
from io_import_scene_unreal_psa_psk_280 import pskimport
from math import *
import json
from random import randint
import threading
from pathlib import Path


working_dir = "D:\\Udump\\UDump\\Fnaf99\\bin\\x64\\Debug\\Dump\\"





def importMesh(filePath):
    return pskimport(filePath,bpy.context,bReorientBones=True)

def fixNan(value):
    if(value=="NaN"):
        return 0
    else:
        return value

def createObject(jsonData):
    objectType = jsonData["type"]
    if(objectType=="mesh"):
        path = jsonData["path"]
        path=path.split('.')[0]
        path=working_dir+"UmodelExport"+path
        if(Path(path+".pskx").is_file()):
            path=path+".pskx"
        elif(Path(path+".psk").is_file()):
            path=path+".psk"
        else:
            print("Can't find mesh file "+path)

            return
        importMesh(path)
        
        imported = bpy.context.active_object
        location = jsonData["position"]
        rotation = jsonData["rotation"]
        scale = jsonData["scale"]
        imported.location = (fixNan(location["X"])/100,fixNan(location["Y"])/100*-1,fixNan(location["Z"]/100))
        imported.rotation_euler = (radians(fixNan(rotation["Z"])),radians(fixNan(rotation["X"])*-1),radians(fixNan(rotation["Y"])*-1))
        imported.scale = (fixNan(scale["X"]),fixNan(scale["Y"]),fixNan(scale["Z"]))

    
        
    




def main():  
    jsonFileData = json.loads((open(working_dir+"dump.json","r").read())) 
    listLen = len(jsonFileData)
    successfulObjects=0
    failedObjects=0
    for i in range(0,listLen):
        createObject(jsonFileData[i])
        print("Imported object "+str(i)+"/"+str(listLen))
        
    print("done! Success: ",successfulObjects, ".Failed: ",failedObjects,".Total: ",failedObjects+successfulObjects)

    textfile = open(working_dir+"brokenObjects.txt", "w")
    for element in nonImportedObjects:
        textfile.write(element + "\n")
    textfile.close()
    

successfulObjects = 0
failedObjects = 0
nonImportedObjects = []
pskObjectCache = {}
main()
